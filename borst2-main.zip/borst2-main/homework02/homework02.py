class Node:
    #Used to create children nodes
    def __init__(self, val):
        self.value = val
        self.children = []
    
    #Used to create a child of the node
    def make_child(self, val):
        temp = Node(val)
        self.children.append(temp)

#Function for minmax
def minmax(node, max_player):
    #If reaches a leaf node, return the value fo the leaf node.
    if node.value != None:
        return node.value
    
    if max_player: 
        bestmax = -1000
        for a in node.children:
            current_value = minmax(a, False)
            bestmax = max(bestmax, current_value)
        return bestmax
    else: 
        bestmin = 1000
        for a in node.children:
            current_value = minmax(a, True)
            bestmin = min(bestmin, current_value)
        return bestmin
        
def main():
    root = Node(None)
    root.make_child(5)
    root.make_child(None)
    
    #This section makes the left side of the tree (from the node to the right of the root node)
    current = root.children[1]
    current.make_child(None)
    current.make_child(None)
    
    current = current.children[0]
    current.make_child(1)
    current.make_child(None)
    
    current = current.children[1]
    current.make_child(4)
    current.make_child(2)
    
    #This section makes the right side of the tree (from the node to the right of the root node)
    current = root.children[1].children[1]
    current.make_child(5)
    current.make_child(None)
    
    current = current.children[1]
    current.make_child(4)
    current.make_child(3)
    
    
    #Call minmax and print the return value
    print("The utility value of the root node is", minmax(root, True))

main()