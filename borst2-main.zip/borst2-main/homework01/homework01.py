#Function calls to main1, main2, and main3 can be found at the bottom of the program.

#Problem 1: Since Alice's goal is to explore the forest and find the tree of wonders, the best 
#search algorithm would be BFS because it would allow alice to complete her goal of exploring the forst. 
#However, based on her goal of just finding the tree of wonders and the structure of the tree, it is
#clear that DFS would be faster at finding the tree of wonders because it is on a leaf node on the right 
#side of the tree. I implemented both BFS and DFS for this search problem and found that DFS found "T" node
#through the exploration of fewer nodes than in BFS.

#Problem 2: The problem says that Sherlock's goal is to find the shortest path between his locaiton 
#and the crime scene. Due to this, I would not want to chose DFS because this could chose the bottom 
#path that goes through B and E instead of the top path; however, this would depend on how I arange the 
#children nodes from sherlock. Additionally, BFS would find the shortest path because it would search
#all of the nodes at a specific depth before moving to a deeper node. I implemented both BFS and DFS on
#this problem and found that DFS found a solution, but not the shortest path and explored more nodes to
#reach this solution than BFS, which also found the shortest path. However, if I were to add the children 
#nodes in a different way, DFS could have found the shortest path while exploring fewer nodes than BFS.


#This section is dedicated to problems 1 and 2: 


#Class for the nodes of the trees/graphs
class Node:
    #The constructor will take the name of the node as the argument
    def __init__(self, node_name):
        self.name = node_name
        self.children = [] #List of children
    
    #This method will add a child node of a specific name to the node
    def make_child(self, child_name):
        child_node = Node(child_name)
        self.children.append(child_node)
        
#This function will create all of the children for problem 1 given the root node
def initialize_tree1(root):
    #Creates B and C as children of A
    root.make_child("B")
    root.make_child("C")

    #Create child D for B Node
    curr_node = root.children[0] #curr_node will be B
    curr_node.make_child("D")

    #Create children G and H for D Node
    curr_node = root.children[0].children[0] #curr_node will be D
    curr_node.make_child("G")
    curr_node.make_child("H")

    #Create children E and F for C Node
    curr_node = root.children[1] #curr_node will be C
    curr_node.make_child("E")
    curr_node.make_child("F")

    #Create child T for F Node
    curr_node = root.children[1].children[1] #curr_node will be F
    curr_node.make_child("T")

#This function will create the graph for problem 2 given the root node
def initialize_tree2(root):
    #Creates A and B as children of S
    root.make_child("A")
    root.make_child("B")
    
    #Create C as a child of A and add S as a child of A
    curr_node = root.children[0] #curr_node will be A
    curr_node.make_child("C")
    curr_node.children.append(root)
    
    #Create E as a child of C and add A as a child of C
    curr_node = root.children[0].children[0] #curr_node will be C
    curr_node.make_child("E")
    curr_node.children.append(root.children[0])
    
    #Create B as a child of E and add C as a child of E
    curr_node = root.children[0].children[0].children[0] #curr_node will be E
    curr_node.make_child("B")
    curr_node.children.append(root.children[0].children[0])
    
    #Create D as a child of B and add E and S as children of B
    curr_node = root.children[1] #curr_node will be B
    curr_node.children.append(root)
    curr_node.children.append(root.children[0].children[0].children[0])
    curr_node.make_child("D")
    
    #Add B as a child of D
    curr_node = root.children[1].children[2] #curr_node will be D
    curr_node.children.append(root.children[1]) 

#This is the function used for DFS
def DFS(initial_node, goal_name):
    #Initialize variables
    frontier = [] #Create frontier list
    explored = [] #Create explored list
    found = 0 #Boolian variable for whether the Node with the goal_name was found
    
    #Add initial state to frontier
    frontier.append(initial_node)
    
    #Search until the frontier is empty or a solution is found
    while len(frontier):
        
        #Make current node the top of the frontier
        current = frontier[-1]
        
        #If the top of the frontier is the goal, break
        if current.name == goal_name:
            found = 1
            break
        else:
            explored.append(current) #Add the top Node to the explored list
            for kid in current.children:
                if kid not in explored:
                    frontier.append(kid) #Add children nodes to frontier
            frontier.remove(current) #Removes explored node from list
        
    return found, explored #Return whether the goal was found and the explored set

#This is the function used for BFS
def BFS(initial_node, goal_name):
    #Initialize variables
    frontier = [] #Create frontier list
    explored = [] #Create explored list
    found = 0 #Boolian variable for whether the Node with the goal_name was found
    
    #Add initial state to frontier
    frontier.append(initial_node)
    
    #Search until the frontier is empty or a solution is found
    while len(frontier):
        
        #Make current node the front of the frontier
        current = frontier[0]
        
        #If the top of the frontier is the goal, break
        if current.name == goal_name:
            found = 1
            break
        else:
            explored.append(current) #Add the front Node to the explored list
            for kid in current.children:
                if kid not in explored:
                    frontier.append(kid) #Add children nodes to frontier
            frontier.remove(current) #Removes explored node from list
        
    return found, explored #Return whether the goal was found and the explored set

#Main function for problem 1
def main1():
    #Initialization
    root = Node("A") #Creates the root node
    initialize_tree1(root) #Creates the rest of the tree
    
    #Call DFS with a goal of "T"
    found, explored = DFS(root, "T")
    
    #Print information about the DFS search
    print("Problem 1 DFS Search Result:")
    if found:
        print("DFS found the goal node")
        print("Explored set is of length:", len(explored), "and contains elements:")
        for a in explored:
            print(a.name)
    else:
        print("DFS did not find the goal node")
        
    #Call BFS with a goal of "T"
    found, explored = BFS(root, "T")
    
    #Print information about the search
    print("Problem 1 BFS Search Result:")
    if found:
        print("BFS found the goal node")
        print("Explored set is of length:", len(explored), "and contains elements:")
        for a in explored:
            print(a.name)
    else:
        print("BFS did not find the goal node")

#Main function for problem 2        
def main2():
    #Initialization
    root = Node("S") #Creates the root node
    initialize_tree2(root)
    
    #Call DFS with a goal of "C"
    found, explored = DFS(root, "C")
    
    #Print information about the search
    print("Problem 2 DFS Search Result:")
    if found:
        print("DFS found the goal node")
        print("Explored set is of length:", len(explored), "and contains elements:")
        for a in explored:
            print(a.name)
    else:
        print("DFS did not find the goal node")
        
    #Call BFS with a goal of "C"
    found, explored = BFS(root, "C")
    
    #Print information about the search
    print("Problem 2 BFS Search Result:")
    if found:
        print("BFS found the goal node")
        print("Explored set is of length:", len(explored), "and contains elements:")
        for a in explored:
            print(a.name)
    else:
        print("BFS did not find the goal node")


#Problem 3: The paths that were found by GBFS and by A* matched the paths that we found in class in this example
#GBFS found the solution that was not optimal, and A* found the solution that was optimal. Interestingly, both of
#these search algorithms explored 27 tiles before reaching the prince. 
        
    
#This section is dedicated to Problem 3:            
        
        
import numpy as np

#Class used for coordinates of a grid     
class Coordinate: 
    def __init__(self, x, y):
        self.x = x
        self.y = y

#Class used for the priority Queue. Items in this queue are NOT sorted by their priority; however,
#the best() method is used to find the best availiable option in this queue to be executed
class priority_queue:
    #This queue is initialized by one element and 
    def __init__(self, first_element, evaluation):
        self.queue = []
        self.queue.append(first_element)
        self.evaluation_function = evaluation
    
    #Uses the evaluation function to determine a numeric value for a specific grid coordinate
    def evaluate(self, point):
        return self.evaluation_function[point.x][point.y]
    
    #This will insert a coordinate into the queue
    def insert_data(self, data):
        self.queue.append(data)
    
    #This will expand the queue to the adjasent tiles if these tiles are not out of bounds, have not been
    #explored, and are on the maze.
    def expand(self, point, maze, explored):
        #If in bounds and it is a walkable path, add the tile x+1 tile to the queue
        possible = 1
        
        if point.x < maze.shape[0] - 1 and maze[point.x + 1][point.y] == 1:
            for a in explored:
                if a.x == point.x + 1 and a.y == point.y:
                    possible = 0
            if possible:
                self.insert_data(Coordinate(point.x + 1, point.y))

        #If in bounds and it is a walkable path, add the tile x-1 tile to the queue
        possible = 1
        
        if point.x > 0 and maze[point.x - 1][point.y] == 1:
            for a in explored:
                if a.x == point.x - 1 and a.y == point.y:
                    possible = 0
            if possible:
                self.insert_data(Coordinate(point.x - 1, point.y))
        
        #If in bounds and it is a walkable path, add the tile y+1 tile to the queue
        possible = 1
        
        if point.y < maze.shape[1] - 1 and maze[point.x][point.y + 1] == 1:
            for a in explored:
                if a.x == point.x and a.y == point.y + 1:
                    possible = 0
            if possible:
                self.insert_data(Coordinate(point.x, point.y + 1))
                
        #If in bounds and it is a walkable path, add the tile y-1 tile to the queue
        possible = 1
        
        if point.y > 0 and maze[point.x][point.y - 1] == 1:
            for a in explored:
                if a.x == point.x and a.y == point.y - 1:
                    possible = 0
            if possible:
                self.insert_data(Coordinate(point.x, point.y - 1))
    
    #This removes a specific coordinate from the queue
    def remove(self, data):
        self.queue.remove(data)
    
    #Finds and returns the coordinate with the best evaluation in the queue
    def best(self):    
        lowest_eval = 100
        for points in self.queue:
            if self.evaluate(points) < lowest_eval:
                lowest_eval = self.evaluate(points)
                best_move = points
                #print("Best move is ({},{})".format(best_move.x, best_move.y))
        return best_move
    
    #Returns the length of the queue
    def length(self):
        return len(self.queue)

#This function will be used for both GBFS and A* search
def informed_search(start, goal, maze, evaluation_function):
    #Initialize variables
    frontier = priority_queue(start, evaluation_function) #Create frontier priority queue and add starting coordinate
    explored = [] #Create explored list
    found = 0 #Boolian variable for whether the goal was found
    
    #Search until the frontier is empty or a solution is found
    while frontier.length():
        
        current = frontier.best() #Make current grid coordinate the front of the frontier
        
        #If the current tile is the goal, break
        if current.x == goal.x and current.y == goal.y:
            found = 1
            break
        else:
            explored.append(current) #Add the current coordinate to the explored list
            
            frontier.expand(current, maze, explored) #Expands frontier to adjacent grid squares
            
            frontier.remove(current) #Remove the current coordinate from the frontier
        
    return found, explored #Return whether the goal was found and the explored set

def main3():
    #The x and y indices of the goal of the maze (the prince) and the starting position (the princess)
    goal = Coordinate(0,9)
    start = Coordinate(6,0)
    
    #Maze: the 1s represent walking paths and the 0s represent walls for the maze
    maze = np.array([[0,1,1,1,1,1,1,1,1,1],
                     [0,1,0,0,0,0,0,0,0,1],
                     [0,1,0,1,1,1,1,1,0,1],
                     [0,1,0,1,0,0,0,1,0,1],
                     [0,1,1,1,0,1,1,1,0,1],
                     [0,0,0,1,0,1,0,0,0,1],
                     [1,1,1,1,0,1,1,1,1,1]])
    
    #Create Matrix for Manhattan Heuristic
    manhattan = np.ones(shape=maze.shape)
    for i in range (7):
        for j in range (10):
            manhattan[i][j] = abs(goal.x - i) + abs(goal.y - j)
            
    #Create Matrix for the Path Cost
    cost = np.array([[0,11,12,13,14,15,16,17,18,19],
                     [0,10,0,0,0,0,0,0,0,26],
                     [0,9,0,7,8,9,10,11,0,25],
                     [0,8,0,6,0,0,0,12,0,24],
                     [0,7,6,5,0,15,14,13,0,23],
                     [0,0,0,4,0,16,0,0,0,22],
                     [0,1,2,3,0,17,18,19,20,21]])        
    
    #Call GBFS (The evaluation function is just the manhattan distance)
    found, explored = informed_search(start, goal, maze, manhattan)
    
    #Print information about the search
    print("Problem 3 GBFS Search Result:")
    if found:
        print("GBFS found the goal node.")
        print("Explored set is of length:", len(explored), "and contains elements:")
        for a in explored:
            print("({},{})".format(a.x, a.y))
    else:
        print("GBFS did not find the goal.")
    
    #Call A* (The evaluation function is just the manhattan distance added to the path cost)
    found, explored = informed_search(start, goal, maze, manhattan + cost)
    
    #Print information about the search
    print("Problem 3 A* Search Result:")
    if found:
        print("A* found the goal node.")
        print("Explored set is of length:", len(explored), "and contains elements:")
        for a in explored:
            print("({},{})".format(a.x, a.y))
    else:
        print("A* did not find the goal.")
    
    
main1() #Call main function for problem 1
main2() #Call main function for problem 2
main3() #Call main function for problem 3
