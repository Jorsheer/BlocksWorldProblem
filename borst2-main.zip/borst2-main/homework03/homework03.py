def print_grid(grid):
    for row in grid:
        print(" ".join(map(str, row)))

def is_valid_move(grid, row, col, num):
    for i in range(4):
        if grid[row][i] == num or grid[i][col] == num:
            return False

    start_row, start_col = 2 * (row // 2), 2 * (col // 2)
    for i in range(start_row, start_row + 2):
        for j in range(start_col, start_col + 2):
            if grid[i][j] == num:
                return False

    return True

def solve_sudoku(grid):
    #This section checks if the sudoku is complete by detecting any 0s in the grid
    complete = 1
    for i in range(4):
        for j in range(4):
            if grid[i][j] == 0:
                complete = 0     
    #Return true if the sukoku is complete     
    if complete:
        return True
    else:
        #Iterates through every index of the grid
        for i in range(4):
            for j in range(4):
                #Tries every possible value that a variable can hold (1-4)
                for number in range(1,5):
                    #If a grid square is 0 and the number is valid, it is tried
                    if grid[i][j] == 0 and is_valid_move(grid, i, j, number):
                        grid[i][j] = number 
                        #This is a recursive call to the function to try the next value
                        if solve_sudoku(grid):
                            return True
                        #Undo the move if it is not possible in a solution
                        grid[i][j] = 0
        #Return false if all continuations are not possible
        return False
                        
            

sudoku_grid = [
    [0, 0, 0, 2],
    [0, 0, 0, 0],
    [1, 0, 0, 0],
    [0, 0, 3, 0]
]

print("Sudoku puzzle:")
print_grid(sudoku_grid)

if solve_sudoku(sudoku_grid):
   print("Solved Sudoku:")
   print_grid(sudoku_grid)
else:
   print("No solution exists.")


